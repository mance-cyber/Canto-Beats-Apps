
  # 影片字幕轉釋編輯器

  This is a code bundle for 影片字幕轉釋編輯器. The original project is available at https://www.figma.com/design/HMngclLqKJcLWpppOekh8a/%E5%BD%B1%E7%89%87%E5%AD%97%E5%B9%95%E8%BD%89%E9%87%8B%E7%B7%A8%E8%BC%AF%E5%99%A8.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  